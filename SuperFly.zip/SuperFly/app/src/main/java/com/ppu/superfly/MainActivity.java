package com.ppu.superfly;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.TextView; // <— After declaring object, this was placed automatically

public class MainActivity extends AppCompatActivity {

    // Declaring our objects on the screen®
    private Button btnSubmit;
    private TextView txtView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Sync screen and code
        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        txtView1 = (TextView) findViewById(R.id.txtView1);

        // Modify text object
        // btnSubmit.setTextColor(Color.WHITE);

        btnSubmit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){ // Method
                txtView1.setVisibility(View.VISIBLE);
                txtView1.setText(R.string.show_text);
            }
        });
    }
}

